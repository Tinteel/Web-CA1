import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms'; 
import { MovieapiService } from '../movieapi-service';
import { inject } from '@angular/core';
import { Results } from '../results/results';

@Component({
  selector: 'app-search',
  imports: [FormsModule],
  templateUrl: './search.html',
  styleUrl: './search.css',
})
export class Search {

  protected movieService_search = inject (MovieapiService);
  protected results_search = inject (Results);

  public title : string ="";

  protected getMovie_Search(title : string)
  {
    this.movieService_search.getMovie(this.title);
    
  }

   protected getMovies_Search(title : string)
  {
    this.movieService_search.getMovies(this.title); 
  
  }

}
